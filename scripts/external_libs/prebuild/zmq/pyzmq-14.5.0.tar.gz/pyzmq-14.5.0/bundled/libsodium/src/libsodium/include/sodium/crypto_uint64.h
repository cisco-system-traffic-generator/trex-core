#ifndef crypto_uint64_H
#define crypto_uint64_H

#include <stdint.h>

typedef uint64_t crypto_uint64;

#endif
